#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "arvores.h"

Arv *arv_criavazia(){
	return NULL;
}

Arv *arv_cria(char c, Arv *sae, Arv *sad){
	Arv *p = (Arv*)malloc(sizeof(Arv));
	p->info = c;
	p->esq = sae;
	p->dir = sad;
	return p;
}

int arv_vazia(Arv *a){
	return a==NULL;
}

void imprime_pre(Arv *arv){
	if(!arv_vazia(arv)){
		printf("%c ", arv->info);
		imprime_pre(arv->esq);
		imprime_pre(arv->dir);
	}
}

void imprime_ord(Arv *arv, FILE *arquivo){
	if(!arv_vazia(arv)){
		imprime_ord(arv->esq, arquivo);
		fprintf(arquivo, "%c ", arv->info);
		imprime_ord(arv->dir, arquivo);
	}
}

void imprime_pos(Arv *arv, FILE *arquivo){
	if(!arv_vazia(arv)){
		imprime_pos(arv->esq, arquivo);
		imprime_pos(arv->dir, arquivo);
		fprintf(arquivo, "%c ", arv->info);
	}
}

Arv *arv_libera(Arv *a){
	if(!arv_vazia(a)){
		arv_libera(a->esq);
		arv_libera(a->dir);
		free(a);
	}
	return NULL;
}

int arv_pertence(Arv *a, char c){
	if(arv_vazia(a)){
		return 0;
	}
	else{
		return a->info==c || arv_pertence(a->esq, c) || arv_pertence(a->dir, c);
	}
}

static int max2(int a, int b){
	return (a>b) ? a:b;
}

int arv_altura(Arv *a){
	if(arv_vazia(a)){
		return -1;
	}
	else{
		return 1 + max2(arv_altura(a->esq), arv_altura(a->dir));
	}
}

Arv *arv_busca(Arv *a, char c){
	if(arv_vazia(a)){
		return NULL;
	}
	else{
		if(a->info == c){
			return a;
		}
		else{
			if(arv_busca(a->esq, c)==NULL && arv_busca(a->dir, c)==NULL){
				return NULL;
			}
			else if(arv_busca(a->esq, c)!=NULL){
				return arv_busca(a->esq, c);
			}
			else{
				return arv_busca(a->dir, c);
			}
		}
	}
}

void arv_insere(Arv *a, char c, char dado, char lado){
	Arv *n = arv_busca(a, c);
	Arv *novo = (Arv *)malloc(sizeof(Arv));

	novo->esq =NULL;
	novo->esq =NULL;
	novo->info = dado;

	if(n==NULL){
		//printf("Elemento nao encontrado\n");
	}
	else{
		if(lado=='e'){
			if(n->esq!=NULL){
				//printf("Lugar já ocupado\n");
			}
			else{
				n->esq = novo;
				//printf("Elemento inserido com sucesso\n");
			}
		}
		else if(lado=='d'){
			if(n->dir!=NULL){
				//printf("Lugar já ocupado\n");
			}
			else{
				n->dir = novo;
				//printf("Elemento inserido com sucesso\n");
			}
		}
	}
}

Lista* lst_insere(Lista *l, Arv *a){
	Lista *novo=(Lista *)malloc(sizeof(Lista));
	Lista *p=l;

	if(a != NULL) novo->arv = a;
	else novo->arv = arv_cria(' ', NULL, NULL);

	if(p==NULL){
		novo->prox = NULL;
		return novo;
	}
	while(p->prox != NULL){
		p=p->prox;
	}

	novo->prox = p->prox;
	p->prox = novo;

	return l;
}

void lst_libera(Lista *l){
	Lista *p = l;
	do{
		Lista *t = p->prox;
		free(p);
		p=t;
	} while(p != NULL);
}

int verificaProximos(Lista *l){
	Lista *p = l;

	while(p != NULL){
		if(p->arv->info != ' ') return 1;
		else p = p->prox;
	}
	return 0;
}

Lista *formaLista(Lista *l, Arv *a){
	l = lst_insere(l, a);
	Lista  *p = l;

	do{
		l = lst_insere(l, p->arv->esq);
		l = lst_insere(l, p->arv->dir);
		p = p->prox;
	} while(verificaProximos(p));

	return l;
}

void arv_imprime(Lista *l, int linha, int alturaArv){
	float numElem = pow(2.0, linha),
		numAntes = (pow(2.0, (alturaArv - linha)) -1),
		numEntre = ((2 * numAntes) + 1),
		i, j;
	Lista *p = l;

	for(i = 0.0; i < numAntes; i++) printf(" ");
	for(i = 0.0; i < numElem; i++){
		if(p != NULL){
			printf("%c", p->arv->info);
			for(j = 0; j < numEntre; j++) printf(" ");
			p = p->prox;
		}
	}
	printf("\n");

	if(linha == alturaArv) return;
	arv_imprime(p, (linha + 1), alturaArv);
}

void arv_imprime_vertical(Arv *arvore){
	Lista *lista = NULL, *p;

	if(!arv_vazia(arvore)){
		lista = formaLista(lista, arvore);
		printf("\nArvore:\n");
		arv_imprime(lista, 0, arv_altura(arvore));
	}

	lst_libera(lista);
}