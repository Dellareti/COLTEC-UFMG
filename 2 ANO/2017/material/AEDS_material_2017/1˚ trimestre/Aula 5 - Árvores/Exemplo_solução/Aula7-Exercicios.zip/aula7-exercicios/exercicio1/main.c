#include <stdio.h>
#include <stdlib.h>
#include "arvores.h"
#include "pilhas.h"

Arv *transformaArvore(Arv *arvore, char expressao[], char lado, int indice){
	Pilha_vet *pilha = pilha_vet_cria();
	Arv *novo = (Arv *)malloc(sizeof(Arv));

	while(1){
		if(expressao[indice]=='+' || expressao[indice]=='-' || expressao[indice]=='*' || expressao[indice]=='/'){
			if(arvore == NULL && pilha_vet_vazia(pilha)){
				novo->info = expressao[indice];
				arvore = novo;
				arvore->esq = transformaArvore(arvore, expressao, 'e', (indice - 1));
				arvore->dir = transformaArvore(arvore, expressao, 'd', (indice + 1));

				return arvore;
			}

			else if(arvore != NULL && pilha->n == 1){
				novo->info = expressao[indice];
				novo->esq = transformaArvore(arvore, expressao, 'e', (indice - 1));
				novo->dir = transformaArvore(arvore, expressao, 'd', (indice + 1));
				
				return novo;
			}
		}

		else if(expressao[indice]==')'){
			if(lado == 'e') pilha_vet_push(pilha, expressao[indice]);
			else pilha_vet_pop(pilha);
		}
				
		else if(expressao[indice]=='('){
			if(lado == 'd') pilha_vet_push(pilha, expressao[indice]);
			else pilha_vet_pop(pilha);
			
		}

		else{
			if(pilha_vet_vazia(pilha) && arvore != NULL){
				novo->info = expressao[indice];
				
				return novo;
			}
		}

		if(lado == 'e') indice--;
		else indice++;

	}
}

int main(){
	Arv *arvore = arv_criavazia();
	char expressao[500];
	FILE *arquivo;

	printf("Insira a expressao matematica: ");
	scanf("%s", expressao);

	arvore = transformaArvore(arvore, expressao, 'd', 0);
	arv_imprime_vertical(arvore);
	
	arquivo = fopen("arquivo.txt", "w");
	fclose(arquivo);
	arquivo = fopen("arquivo.txt", "a");
	fprintf(arquivo, "Versao Infixa:\n");
	imprime_ord(arvore, arquivo);
	fprintf(arquivo, "\nVersao Pos-fixa:\n");
	imprime_pos(arvore, arquivo);
	fclose(arquivo);

	arv_libera(arvore);
	return 0;
}