#include <stdio.h>
#include <stdlib.h>
#include "arvores2.h"

int numFolhas(ArvVar *arvore){
	ArvVar *p;
	int num = 0;

	for(p = arvore->prim; p != NULL; p = p->prox){
		num += numFolhas(p);
		if(p->prim == NULL) num += 1;
	}

	return num;
}

int main(){
	ArvVar *arvore = arvv_cria('1');

	arvv_insere(arvore, '2');
	arvv_insere(arvore, '3');
	arvv_insere(arvore->prim, '4');
	arvv_insere(arvore->prim->prim, '5');
	arvv_insere(arvore->prim->prim, '6');
	arvv_insere(arvore, '7');
	arvv_insere(arvore->prim, '8');
	arvv_insere(arvore->prim, '9');
	arvv_insere(arvore->prim->prim, 'A');
	arvv_insere(arvore->prim, 'B');
	arvv_insere(arvore->prim, 'C');

	printf("\nNum de folhas: %d\n\n", numFolhas(arvore));

	arvv_libera(arvore);
	return 0;
}
