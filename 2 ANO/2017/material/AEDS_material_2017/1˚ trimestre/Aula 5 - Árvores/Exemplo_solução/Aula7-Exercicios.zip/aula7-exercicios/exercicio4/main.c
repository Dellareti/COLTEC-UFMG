#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include "fila.h"

void fila_insere_ordenado_l(FilaL *fila, int ID){
	Lista *primeiro = fila->ini;
	Lista *p = primeiro;
	int controle = 0;

	Lista *novo = (Lista *)malloc(sizeof(Lista));
	novo->info = ID;

	if(!fila_vazia_l(fila)){
		if(fila->fim->info > ID) fila_insere_l(fila, novo);
		else{
			if(fila->ini->info < ID) primeiro = novo;

			do{
				p = fila_retira_l(fila);

				if(p->info > ID) fila_insere_l(fila, p);
				else if(controle != 1){
					controle = 1;
					fila_insere_l(fila, novo);
				}

				fila_insere_l(fila, p);
				p = fila->ini;
			} while(p != primeiro);
		}
	}
	else{
		fila_insere_l(fila, novo);
	}

	printf("Processo inserido com sucesso!\n");
}

int main(){
	FilaL *fila = fila_cria_l();
	int opcao = 0, tempoID;
	do{
		system("clear");
		printf("\n*BEM VINDO AO GERENCIADOR DE PROCESSOS*\n");
		printf("\nO que deseja fazer?\n(0) Sair\n(1) Incluir processo na fila\n(2) Retirar precesso com maior tempo de espera\n(3) Imprimir processos na fila\n");
		scanf("%d", &opcao);

		switch(opcao){
			case 0: printf("Obrigado por utilizar nossos servicos. Volte sempre!\n");
					break;
			case 1: printf("Insira o tempo de espera do processo: \n");
					scanf("%d", &tempoID);
					fila_insere_ordenado_l(fila, tempoID);
					fila_imprime_l(fila);
					break;
			case 2: fila_retira_l(fila);
					fila_imprime_l(fila);
					break;
			case 3: fila_imprime_l(fila);
					break;
			default: printf("Opcao invalida!\n");
					 break;
		}

		printf("Pressione ENTER para continuar...\n");
		__fpurge(stdin);
		getchar();

	} while(opcao != 0);

	fila_libera_l(fila);
	return 0;
}