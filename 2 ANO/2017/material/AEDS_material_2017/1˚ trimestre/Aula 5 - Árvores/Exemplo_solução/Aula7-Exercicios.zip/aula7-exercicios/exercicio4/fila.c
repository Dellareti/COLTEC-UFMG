#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

// Lista encadeada
FilaL *fila_cria_l(){
	FilaL *f = (FilaL *) malloc(sizeof(FilaL));
	f->ini = f->fim = NULL;
	return f;
}

void fila_insere_l(FilaL *f, Lista *n){
	n->prox = NULL;

	if(f->fim != NULL) f->fim->prox = n;
	else f->ini = n;
	f->fim = n;
}

Lista *fila_retira_l(FilaL *f){
	Lista *t;
	int v;
	if(fila_vazia_l(f)){
		printf("Fila vazia!\n");
		return 0;
	}
	t = f->ini;
	f->ini = t->prox;
	if(f->ini==NULL) f->fim = NULL;
	return t;
}

int fila_vazia_l(FilaL *f){
	return (f->ini == NULL);
}

void fila_libera_l(FilaL *f){
	Lista *q = f->ini;
	while(q!=NULL){
		Lista *t = q->prox;
		free(q);
		q = t;
	}
	free(f);
}

// Funções de impressão

void fila_imprime_l(FilaL *f){
	Lista *q;
	printf("Fila:\n");
	if(!fila_vazia_l(f)) for(q=f->ini; q!=NULL; q=q->prox) printf("\t%d\n",q->info);
}