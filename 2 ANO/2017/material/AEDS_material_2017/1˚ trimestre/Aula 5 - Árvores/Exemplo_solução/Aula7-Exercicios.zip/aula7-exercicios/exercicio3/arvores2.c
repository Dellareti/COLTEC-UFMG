#include <stdio.h>
#include <stdlib.h>
#include "arvores2.h"

ArvVar *arvv_cria(char c){
	ArvVar *novo = (ArvVar *)malloc(sizeof(ArvVar));
	novo->info = c;
	novo->num = 0;
	novo->prim = NULL;
	novo->prox = NULL;
	return novo;
}

void arvv_insere(ArvVar *a, char c){
	ArvVar *novo = arvv_cria(c);
	novo->prox = a->prim;
	a->prim = novo;
}

void arvv_imprime(ArvVar *a){
	ArvVar *p;
	printf("%c\n", a->info);
	for(p = a->prim; p != NULL; p = p->prox) arvv_imprime(p);
}

int arvv_pertence(ArvVar *a, char c){
	ArvVar *p;
	if(a->info == c) return 1;
	else{
		for(p = a->prim; p != NULL; p = p->prox){
			if(arvv_pertence(p, c)) return 1;
		}
		return 0;
	}
}

void arvv_libera(ArvVar *a){
	ArvVar *p = a->prim;
	while(p != NULL){
		ArvVar *t = p->prox;
		arvv_libera(p);
		p = t;
	}
	free(a);
}

int arvv_altura(ArvVar *a){
	int hmax = -1;
	ArvVar *p;

	for(p = a->prim; p != NULL; p = p->prox){
		int h = arvv_altura(p);
		if(h > hmax) hmax = h;
	}
	return hmax + 1;
}