#include <stdio.h>
#include <stdlib.h>
#include "arvores2.h"

void contaFilhos(ArvVar *arvore){
	ArvVar *p;
	int cont = 0;

	for(p = arvore->prim; p != NULL; p = p->prox){
		cont++;
		contaFilhos(p);
	}

	arvore->num = cont;
}

void imprimeNum(ArvVar *arvore){
	ArvVar *p;

	printf("No de elemento %c: %d\n", arvore->info, arvore->num);
	for(p = arvore->prim; p != NULL; p = p->prox) imprimeNum(p);
}

int main(){
	ArvVar *arvore = arvv_cria('1');

	arvv_insere(arvore, '2');
	arvv_insere(arvore, '3');
	arvv_insere(arvore->prim, '4');
	arvv_insere(arvore->prim->prim, '5');
	arvv_insere(arvore->prim->prim, '6');
	arvv_insere(arvore, '7');
	arvv_insere(arvore->prim, '8');
	arvv_insere(arvore->prim, '9');
	arvv_insere(arvore->prim->prim, 'A');
	arvv_insere(arvore->prim, 'B');
	arvv_insere(arvore->prim->prim, 'C');

	contaFilhos(arvore);
	imprimeNum(arvore);

	arvv_libera(arvore);
	return 0;
}

/*REPRESENTACAO DA ARVORE CRIADA ACIMA*/
//
//		1
//		7-3-2
//		| |
//		| 4
//		| |
//		| 6-5
//		B-9-8
//		| |
//		C A