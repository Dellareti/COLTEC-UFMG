#include <stdio.h>
#include <stdlib.h>

struct arv{
	char info;
	struct arv *esq;
	struct arv *dir;
};
typedef struct arv Arv;

struct lista{
	Arv *arv;
	struct lista *prox;
};
typedef struct lista Lista;

Arv *arv_criavazia();
Arv *arv_cria(char c, Arv *sae, Arv *sad);
int arv_vazia(Arv *a);
void imprime_pre(Arv *arv);
void imprime_ord(Arv *arv, FILE *arquivo);
void imprime_pos(Arv *arv, FILE *arquivo);
Arv *arv_libera(Arv *a);
int arv_pertence(Arv *a, char c);
static int max2(int a, int b);
int arv_altura(Arv *a);
Arv *arv_busca(Arv *a, char c);
void arv_insere(Arv *a, char c, char dado, char lado);
int verificaProximos(Lista *l);
Lista *formaLista(Lista *l, Arv *a);
void arv_imprime(Lista *l, int linha, int alturaArv);
void arv_imprime_vertical(Arv *arvore);


Lista* lst_insere(Lista *l, Arv *a);
void lst_libera(Lista *l);