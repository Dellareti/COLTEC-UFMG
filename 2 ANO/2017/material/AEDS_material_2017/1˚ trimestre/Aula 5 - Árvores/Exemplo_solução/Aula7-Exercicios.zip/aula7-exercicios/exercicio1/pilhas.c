#include <stdio.h>
#include <stdlib.h>
#include "pilhas.h"

//Pilhas com vetor
Pilha_vet *pilha_vet_cria() {
	Pilha_vet *p = (Pilha_vet *) malloc(sizeof(Pilha_vet));
	p->n = 0;

	return p;
}

void pilha_vet_push(Pilha_vet *p, char v) {
	if (p->n == N) {
		printf("A capacidade da pilha estorou.");
		exit(1);
	}

	p->vet[p->n++] = v;
}

char pilha_vet_pop(Pilha_vet *p) {
	if (pilha_vet_vazia(p)) {
		printf("Pilha vazia.");
		exit(1);
	}

	return p->vet[--p->n];
}

int pilha_vet_vazia(Pilha_vet *p) {
	return (p->n == 0);
}

void pilha_vet_libera(Pilha_vet *p) {
	if(p != NULL) free(p);
}

/*int parenteses(){
	Pilha_vet *pilha=pilha_vet_cria();
	char caracter;

	do{
		scanf("%c", &caracter);
		if(caracter == ')'){
			if(pilha_vet_vazia(pilha)){
				printf("Errado\n");
				exit(1);
			}
			else{
				pilha_vet_pop(pilha);
			}
		}
		else if (caracter == '('){
			pilha_vet_push(pilha, caracter);
		}

	} while(caracter != 'q' && caracter != 'Q');

	if(pilha_vet_vazia(pilha)){
		printf("Correto\n");
	}
	else{
		printf("Errado\n");
	}

	pilha_vet_libera(pilha);

	return 0;
}*/