struct arvvar{
	char info;
	struct arvvar *prim;
	struct arvvar *prox;
};
typedef struct arvvar ArvVar;

ArvVar *arvv_cria(char c);
void arvv_insere(ArvVar *a, char c);
void arvv_imprime(ArvVar *a);
int arvv_pertence(ArvVar *a, char c);
void arvv_libera(ArvVar *a);
int arvv_altura(ArvVar *a);