/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpfinal;

/**
 *
 * @author germano
 */
public class Voo {
    /*Data de partida;
    Número de vagas.*/
    private String dataDePartida;
    private int numeroDeVagas;
    
    DescricaoDeVoo descricao;
    Aviao aviao;
    
    public void setNumeroDeVagas(int numeroDeVagas) {
        this.numeroDeVagas = numeroDeVagas;
    }
    
    public String getDataDePartida () {
        return this.dataDePartida;
    }
    
    public int getNumeroDeVagas () {
        return this.numeroDeVagas;
    }
}
