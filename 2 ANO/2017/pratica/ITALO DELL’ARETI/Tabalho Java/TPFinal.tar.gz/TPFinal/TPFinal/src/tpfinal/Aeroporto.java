/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpfinal;

import java.util.Set;

/**
 *
 * @author germano
 */
public class Aeroporto {
    
    private String nome;
    private static int codigo;
    private String nomeDaCidade;
    Set<Aviao> avioes;
    
    Aeroporto() {
        Aeroporto.codigo = Aeroporto.codigo++;
    }
    
    Aeroporto (String nome, String nomeDaCidade) {
        this();
    }
    
    public String getNome() {
        return this.nome;
    }
    
    public String getNomeDaCidade() {
        return this.nomeDaCidade;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void setNomeDaCidade(String nomeDaCidade) {
        this.nomeDaCidade = nomeDaCidade;
    }
}
