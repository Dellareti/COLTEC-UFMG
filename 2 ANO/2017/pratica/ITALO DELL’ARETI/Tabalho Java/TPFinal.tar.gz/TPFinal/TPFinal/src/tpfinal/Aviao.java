/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpfinal;

/**
 *
 * @author germano
 */
public class Aviao {
    
    private final String nomeDoFabricante;
    private final int numeroDoModelo;
    private final int numeroDeAssentos;
    
    /**
     * Construtor obrigatório para setar os parâmetros
     * @param nomeDoFabricante
     * @param numeroDoModelo
     * @param numeroDeAssentos 
     */
    
    Aviao (String nomeDoFabricante, int numeroDoModelo, int numeroDeAssentos) {
        this.nomeDoFabricante = nomeDoFabricante;
        this.numeroDoModelo = numeroDoModelo;
        this.numeroDeAssentos = numeroDeAssentos;
    }
}
