/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpfinal;

import java.util.Set;

/**
 *
 * @author germano
 */
public class Cliente {
    
    private String nome;
    private int telefone;
    private String endereco;
    private String cpf;
    
    Set<Voo> reservaDeViagens;
    
    public Cliente (String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }
    
    public Cliente(String nome, String cpf, int telefone, String endereco) {
        this(nome, cpf);
        this.telefone = telefone;
        this.endereco = endereco;
    }
    
    /**
     * setar o telefone do cliente
     * @param telefone 
     */
    public void setTelefone (int telefone) {
        this.telefone = telefone;
    }
    
    
    /**
     * setar o nome do cliente
     * @param nome 
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    /**
     * setar o endereco do cliente
     * @param endereco 
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    /**
     * retorna o nome do cliente
     * @return 
     */
    public String getNome() {
        return this.nome;
    }
    
    /**
     * retorna o telefone do cliente
     * @return 
     */
    public int getTelefone() {
        return this.telefone;
    }
    
    
    /**
     * retorna o endereco do cliente
     * @return 
     */
    public String getEndereco() {
        return this.endereco;
    }
    
    /**
     * 
     * retorna o cpf do cliente
     * @return 
     */
    public String getCpf() {
        return this.cpf;
    }
}
