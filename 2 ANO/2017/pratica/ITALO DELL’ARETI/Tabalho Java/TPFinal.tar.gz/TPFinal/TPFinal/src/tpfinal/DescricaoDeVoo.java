/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpfinal;

/**
 *
 * @author germano
 */
public class DescricaoDeVoo {
    
    private int horarioDePartida;
    private int horarioDeChegada;
    private static int numero;
    
    /**
     * 
     * @param horarioDePartida
     * @param horarioDeChegada 
     */
    public DescricaoDeVoo(int horarioDePartida, int horarioDeChegada) {
        this.horarioDePartida = horarioDePartida;
        this.horarioDeChegada = horarioDeChegada;
        DescricaoDeVoo.numero = DescricaoDeVoo.numero++; //Tentar fazer com banco de dados
    }
    
    public void setHorarioDePartida(int horarioDePartida) {
        this.horarioDePartida = horarioDePartida;
    }
    
    public void setHorarioDeChegada(int horarioDeChegada) {
        this.horarioDeChegada = horarioDeChegada;
    }
    
    public int getHorarioDePartida() {
        return this.horarioDePartida;
    }
    
    public int getHorarioDeChegada() {
        return this.horarioDeChegada;
    }
    
    public int getNumero() {
        return DescricaoDeVoo.numero;
    }
}
